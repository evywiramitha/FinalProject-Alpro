const labels = document.querySelectorAll('label');
const copy_btns = document.querySelectorAll('label .copy');

document.addEventListener('keypress', (e)=>{
    if(e.key === ' ') {
        generatorWarna();
    }
})

function generatorWarna() {
    for(const label of labels) {
        let warna = '#' + Math.random().toString(16).slice(2, 8);
        label.style.backgroundColor = warna;

        label.querySelector('.color-value').innerText = warna;

        const color_picker = label.nextElementSibling;
        color_picker.value = warna;

        color_picker.oninput = function(){
            this.previousElementSibling.style.backgroundColor = this.value;
            this.previousElementSibling.querySelector('p').innerText = this.value;
        }
    }
}

for (const copy_btn of copy_btns) {
    copy_btn.onclick = () => {
        copy_btn.innerText = 'tersalin';
        setTimeout(() => copy_btn.innerText = 'salin', 1500);

        const color_code = copy_btn.nextElementSibling.innerText;
        navigator.clipboard.writeText(color_code);
    }
}

generatorWarna();