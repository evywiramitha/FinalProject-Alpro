const ideasData = {
    "Teknologi": {
        "Aplikasi": {
            "Orang kesulitan mengelola waktu mereka.": [
                "Aplikasi manajemen waktu dengan AI yang memprioritaskan tugas.",
                "Aplikasi pengingat berbasis kebiasaan pengguna.",
                "Aplikasi produktivitas dengan teknik Pomodoro."
            ],
            "Kesulitan dalam mempelajari keterampilan baru.": [
                "Aplikasi pembelajaran interaktif berbasis video tutorial.",
                "Aplikasi kursus berbasis proyek untuk keterampilan praktis.",
                "Aplikasi simulasi 3D untuk pelatihan teknis."
            ],
            "Penyediaan makanan yang lebih sehat.": [
                "Aplikasi resep sehat yang disesuaikan dengan preferensi pengguna.",
                "Aplikasi diet dengan analisis kesehatan pengguna.",
                "Aplikasi pengantaran bahan makanan segar."
            ]
        },
        "Layanan": {
            "Orang kesulitan mengelola waktu mereka.": [
                "Layanan pelatihan manajemen waktu online.",
                "Layanan konsultasi produktivitas berbasis prioritas.",
                "Layanan coaching tujuan harian."
            ],
            "Penyediaan makanan yang lebih sehat.": [
                "Catering sehat berbasis kebutuhan diet.",
                "Pengantaran makanan sehat dengan menu personalisasi.",
                "Konsultasi diet berbasis aplikasi."
            ]
        },
        "Produk": {
            "Orang kesulitan mengelola waktu mereka.": [
                "Planner digital sinkronisasi otomatis.",
                "Jam pintar dengan pengingat kegiatan.",
                "Gadget berbasis suara untuk pengingat tugas."
            ]
        },
        "Platform": {
            "Orang kesulitan mengelola waktu mereka.": [
                "Platform untuk manajemen waktu berbasis AI.",
                "Platform berbasis cloud untuk kolaborasi tim.",
                "Platform integrasi aplikasi produktivitas."
            ]
        }
    },
    "Kesehatan": {
        "Aplikasi": {
            "Kesulitan memantau kesehatan pribadi.": [
                "Aplikasi pelacak aktivitas fisik berbasis AI.",
                "Aplikasi pencatat asupan nutrisi harian.",
                "Aplikasi monitoring kesehatan mental dengan jurnal otomatis."
            ],
            "Kesulitan mengakses layanan kesehatan.": [
                "Aplikasi telemedis dengan dokter on-demand.",
                "Peta lokasi rumah sakit dan apotek terdekat.",
                "Aplikasi booking tes kesehatan secara online."
            ]
        },
        "Layanan": {
            "Penyediaan perawatan kesehatan terjangkau.": [
                "Layanan konsultasi dokter murah via aplikasi.",
                "Pemeriksaan kesehatan rutin berbasis langganan.",
                "Layanan pengantaran obat berbasis lokasi."
            ],
            "Edukasi kesehatan masyarakat.": [
                "Webinar edukasi kesehatan bulanan.",
                "Program pelatihan kesehatan komunitas.",
                "Akses video tutorial tentang first aid."
            ]
        }
    },
    "Pendidikan": {
        "Platform": {
            "Kesulitan mengakses pendidikan berkualitas.": [
                "Platform e-learning dengan harga terjangkau.",
                "Kelas online live bersama mentor profesional.",
                "Materi pendidikan interaktif berbasis AR/VR."
            ],
            "Keterbatasan alat pembelajaran digital.": [
                "Portal resource belajar untuk pelajar di daerah terpencil.",
                "Platform pinjaman alat pembelajaran digital.",
                "Marketplace buku bekas yang terjangkau."
            ]
        },
        "Layanan": {
            "Kesenjangan keterampilan di dunia kerja.": [
                "Layanan pelatihan keterampilan digital singkat.",
                "Pelatihan bahasa asing intensif untuk pekerjaan global.",
                "Program bimbingan kerja dengan mentor dari industri."
            ]
        }
    }
};

function displayMessage(container, message, isError = false) {
    container.innerHTML = '';
    const messageElement = document.createElement('p');
    messageElement.textContent = message;
    messageElement.style.color = isError ? 'red' : 'black';
    container.appendChild(messageElement);
}


function generateIdea() {
   
    const category = document.getElementById('category').value;
    const model = document.getElementById('model').value;
    const problem = document.getElementById('problem').value;
    const amount = parseInt(document.getElementById('amount').value, 10);

   
    const resultContainer = document.getElementById('business-idea');
    resultContainer.innerHTML = ''; 

    
    function validateAmount() {
        const amountInput = document.getElementById("amount");
        const amount = parseInt(amountInput.value, 10);
    
        
        if (amount < 1 || amount > 3) {
            alert("Masukkan jumlah ide antara 1 hingga 3.");
            amountInput.value = 1; 
        }
    }
    
   
    document.getElementById("amount").addEventListener("input", validateAmount);
    

    
    const ideas = ideasData[category]?.[model]?.[problem];

    if (!ideas || ideas.length === 0) {
        displayMessage(resultContainer, 'Tidak ada ide yang ditemukan untuk pilihan Anda. Coba pilihan lainnya.', true);
        return;
    }

    
    const selectedIdeas = ideas.slice(0, amount);

    
    selectedIdeas.forEach(idea => {
        const ideaElement = document.createElement('p');
        ideaElement.textContent = idea;
        resultContainer.appendChild(ideaElement);
    });

}

