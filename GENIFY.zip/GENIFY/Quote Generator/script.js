const QuoteText = document.querySelector(".quote");

const API_KEY = "clhKPv833XeZbY1Sc/RP9Q==pNwgtOZnVZTZLiuT";

quoteBtn = document.querySelector("button");
authorName = document.querySelector(".author .name");
soundBtn = document.querySelector(".sound");
copyBtn = document.querySelector(".copy");
shareBtn = document.querySelector(".share");


function randomQuote() {
    quoteBtn.classList.add("loading");
    quoteBtn.innerHTML = "Loading..."
    fetch("https://api.api-ninjas.com/v1/quotes", {
        method: "GET",
        headers: { "X-Api-Key": API_KEY }
    }).then(response => response.json()).then(result => {
        console.log(result);
        QuoteText.innerText = result[0].quote;
        authorName.innerText = result[0].author;
        quoteBtn.innerText = "New Quote";
        quoteBtn.classList.remove("loading");
    }).catch(error => {
        console.error("Error fetching the quote:", error);
        quoteBtn.innerText = "Try Again";
        quoteBtn.classList.remove("loading");
    });    
}

quoteBtn.addEventListener("click", randomQuote)

shareBtn.addEventListener("click", event => {
    if (navigation.share) {
        navigator.share({
            title: 'Quote of the Day',
            text: QuoteText.innerText + '--' + authorName.innerText,
        }).then(()=>console.log("successful share"))
        .catch((error)=> console.log("Error sharing", error));
    }
    else {
        alert("The current browser does not support the share function. Please share link manually.")
    }
})

soundBtn.addEventListener("click", () => {
    let utterance = new SpeechSynthesisUtterance(QuoteText.innerText + 'by' + authorName.innerText)
    speechSynthesis.speak(utterance);
});

copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(QuoteText.innerText + ' -- ' + authorName.innerText)
    alert("Quote copied to clipboard")
});