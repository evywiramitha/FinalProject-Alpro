function generateActivity() {
  const age = document.getElementById('age').value;
  const gender = document.getElementById('gender').value;
  const category = document.getElementById('category').value;
  const activityBox = document.getElementById('activity-box');
  const activityImage = document.getElementById('activity-image');
  const activityTitle = document.getElementById('activity-title');
  const activityBenefit = document.getElementById('activity-benefit');
  const activityTips = document.getElementById('activity-tips');

  if (!age || !gender || !category) {
    alert("Harap isi semua input!");
    return;
  }
  if (age < 0) {
    alert("Umur tidak boleh negatif!");
    return;
  }
  if (age > 120) {
    alert("Umur tidak boleh lebih dari 120 tahun!");
    return;
  }

  const activities = {
    Olahraga: [
      { 
        title: "Permainan bola kecil", 
        image: "asset/bola-kecil.jpeg",
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Meningkatkan koordinasi tangan dan mata.", 
        tips: "Lakukan pemanasan sebelum bermain." 
      },
      { 
        title: "Berjalan di atas garis", 
        image: "asset/berjalan-garis.jpg", 
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Meningkatkan keseimbangan dan konsentrasi.", 
        tips: "Gunakan pita warna-warni untuk menarik perhatian anak." 
      },
      { 
        title: "Bersepeda", 
        image: "asset/bersepeda.jpg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Meningkatkan daya tahan tubuh.", 
        tips: "Gunakan pelindung lutut dan helm." 
      },
      { 
        title: "Lari pagi", 
        image: "asset/lari pagi.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Meningkatkan kesehatan jantung dan paru-paru.", 
        tips: "Pilih waktu pagi hari agar udara lebih segar." 
      },
      { 
        title: "Bermain bulu tangkis", 
        image: "asset/bulu-tangkis.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Meningkatkan koordinasi dan refleks.", 
        tips: "Gunakan raket yang ringan untuk anak-anak." 
      },
      { 
        title: "Melakukan skipping (lompat tali)", 
        image: "asset/skipping.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Melatih kelincahan dan kebugaran.", 
        tips: "Pastikan area bermain aman dan luas." 
      },
      { 
        title: "Yoga ringan", 
        image: "asset/yoga-ringan.jpeg", 
        ageRange: [13, 35], 
        gender: "female",
        benefit: "Membantu mengurangi stres dan meningkatkan fleksibilitas.",
        tips: "Fokus pada pernapasan saat melakukan gerakan." 
      },
      {
      title: "Bermain futsal", 
      image: "asset/futsal.jpeg", 
      ageRange: [13, 35], 
      gender: "male",
      benefit: "Meningkatkan kerja sama tim dan kebugaran tubuh.", 
      tips: "Gunakan sepatu futsal yang nyaman." 
    },
    { 
      title: "Zumba", 
      image: "asset/zumba.jpeg", 
      ageRange: [13, 35], 
      gender: "female",
      benefit: "Melatih kebugaran dan koordinasi tubuh.", 
      tips: "Ikuti kelas zumba dengan teman untuk motivasi lebih." 
    },
    { 
      title: "Jogging", 
      image: "asset/jogging.jpeg", 
      ageRange: [13, 35], 
      gender: "all",
      benefit: "Meningkatkan kesehatan jantung dan kekuatan kaki.", 
      tips: "Gunakan sepatu lari yang nyaman." 
    },
    { 
      title: "Senam pagi", 
      image: "asset/senam-pagi.jpeg", 
      ageRange: [35, 100], 
      gender: "all",
      benefit: "Menjaga kesehatan jantung dan otot.",
      tips: "Lakukan dengan gerakan perlahan dan stabil." 
    },
    { 
      title: "Tai Chi", 
      image: "asset/taichi.jpeg", 
      ageRange: [35, 100], 
      gender: "all",
      benefit: "Meningkatkan keseimbangan dan fleksibilitas.", 
      tips: "Latihan ini sangat baik untuk relaksasi pikiran." 
    },
    { 
      title: "Berenang santai", 
      image: "asset/berenang.jpeg", 
      ageRange: [35, 100], 
      gender: "all",
      benefit: "Menguatkan otot tanpa memberikan tekanan besar.", 
      tips: "Lakukan di kolam yang aman dan nyaman." 
    },
    { 
      title: "Jalan kaki santai", 
      image: "asset/jalan-santai.jpeg", 
      ageRange: [35, 100], 
      gender: "all",
      benefit: "Meningkatkan sirkulasi darah.", 
      tips: "Pilih rute yang memiliki pemandangan menarik." 
    },
    { 
      title: "Aerobik ringan", 
      image: "asset/aerobik-ringan.jpeg", 
      ageRange: [35, 100], 
      gender: "all",
      benefit: "Meningkatkan kesehatan jantung.", 
      tips: "Ikuti panduan instruktur untuk gerakan yang tepat." 
     }
    ],
    Hiburan: [
      { 
        title: "Menonton kartun", 
        image: "asset/nonton-kartun.jpeg", 
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Mengembangkan kreativitas dan imajinasi.",
        tips: "Pilih kartun yang edukatif untuk anak-anak." 
      },
      { 
        title: "Membaca buku cerita", 
        image: "asset/baca-buku.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Meningkatkan kemampuan membaca dan pemahaman cerita.",
        tips: "Cobalah untuk membaca dengan suara keras untuk meningkatkan keterampilan berbicara." 
      },
      { 
        title: "Menonton film di bioskop", 
        image: "asset/nonton-bioskop.jpeg", 
        ageRange: [13, 18], 
        gender: "all",
        benefit: "Meningkatkan imajinasi dan ketahanan mental.",
        tips: "Menonton dalam waktu yang terbatas agar tidak mengganggu rutinitas." 
      },
      { 
        title: "Menghadiri konser", 
        image: "asset/konser.jpeg", 
        ageRange: [18, 35], 
        gender: "all",
        benefit: "Meningkatkan rasa kebersamaan dan menikmati musik secara langsung.",
        tips: "Bawa earplugs jika suara terlalu keras." 
      },
      { 
        title: "Mendengarkan musik klasik", 
        image: "asset/musik-klasik.jpeg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Menenangkan pikiran dan meningkatkan konsentrasi.",
        tips: "Dengarkan dalam suasana yang tenang." 
      },
      { 
        title: "Berkumpul dengan teman untuk bermain permainan papan", 
        image: "asset/boardgame.jpeg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Melatih strategi dan mempererat hubungan sosial.", 
        tips: "Pilih permainan yang sesuai dengan selera kelompok." 
      },
      { 
        title: "Mengikuti klub buku atau komunitas literasi", 
        image: "asset/club-buku.jpeg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Berinteraksi dengan orang lain dan memperluas wawasan.", 
        tips: "Cari klub yang aktif di lingkungan sekitar atau online." 
      },
      { 
        title: "Melakukan perjalanan wisata lokal", 
        image: "asset/wisata-lokal.jpg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Mengurangi stres dan menambah pengalaman baru.", 
        tips: "Pilih destinasi yang nyaman dan mudah dijangkau." 
      }
    ],
    Seni: [
      { 
        title: "Menggambar dengan krayon", 
        image: "asset/krayon.jpg", 
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Meningkatkan keterampilan motorik halus.",
        tips: "Beri ruang untuk kreativitas tanpa batasan." 
      },
      { 
        title: "Menyusun puzzle sederhana", 
        image: "asset/puzzle.jpeg", 
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Meningkatkan keterampilan memecahkan masalah.", 
        tips: "Pilih puzzle dengan gambar menarik untuk anak." 
      },
      { 
        title: "Bermain dengan balok bangunan", 
        image: "asset/main-blok.jpeg", 
        ageRange: [0, 5], 
        gender: "all",
        benefit: "Melatih koordinasi tangan dan mata.", 
        tips: "Arahkan anak untuk mencoba berbagai bentuk bangunan." 
      },
      { 
        title: "Bermain video game edukasi", 
        image: "asset/video-game.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Mengembangkan kemampuan kognitif dan pemecahan masalah.", 
        tips: "Pilih game dengan unsur edukasi tinggi." 
      },
      { 
        title: "Mengunjungi taman hiburan", 
        image: "asset/taman-hiburan.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Menambah pengalaman dan rasa percaya diri.", 
        tips: "Pastikan anak diawasi saat mencoba wahana." 
      },
      { 
        title: "Bermain alat musik sederhana", 
        image: "asset/alat-musik.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Meningkatkan kemampuan motorik dan ritme.", 
        tips: "Pilih alat musik yang sesuai dengan usia anak." 
      },
      { 
        title: "Belajar origami", 
        image: "asset/origami.jpeg", 
        ageRange: [6, 12], 
        gender: "all",
        benefit: "Melatih kesabaran dan ketelitian.",
        tips: "Mulailah dengan bentuk sederhana." 
      },
      { 
        title: "Melukis di kanvas", 
        image: "asset/melukis.jpg", 
        ageRange: [13, 18], 
        gender: "all",
        benefit: "Meningkatkan ekspresi diri melalui seni.",
        tips: "Pilih cat yang sesuai dengan media kanvas." 
      },
      { 
        title: "Belajar bermain gitar", 
        image: "asset/gitar.jpeg", 
        ageRange: [18, 35], 
        gender: "male",
        benefit: "Mengembangkan keterampilan musik dan koordinasi tangan.",
        tips: "Praktikkan secara rutin untuk menguasai teknik." 
      },
      { 
        title: "Merajut", 
        image: "asset/merajut.jpg", 
        ageRange: [18, 35], 
        gender: "female",
        benefit: "Mengurangi stres dan meningkatkan konsentrasi.",
        tips: "Pilih benang yang nyaman dan mulailah dari proyek kecil." 
      },
      { 
        title: "Mengunjungi galeri seni atau museum", 
        image: "asset/museum.jpg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Menambah wawasan dan inspirasi seni.", 
        tips: "Cari pameran yang sedang berlangsung di daerah sekitar." 
      },
      { 
        title: "Menulis puisi atau cerita pendek", 
        image: "asset/menulis.jpg", 
        ageRange: [35, 100], 
        gender: "all",
        benefit: "Mengasah keterampilan bahasa dan menyalurkan emosi.", 
        tips: "Gunakan jurnal pribadi untuk mencatat ide-ide kreatif." 
      }
    ]
  };

  const selectedActivities = activities[category].filter(
    (activity) =>
      age >= activity.ageRange[0] &&
      age <= activity.ageRange[1] &&
      (activity.gender === "all" || activity.gender === gender)
  );

  if (selectedActivities.length === 0) {
    alert("Maaf, tidak ada aktivitas yang sesuai dengan kategori, umur, dan gender Anda.");
    return;
  }

  const randomActivity = selectedActivities[Math.floor(Math.random() * selectedActivities.length)];

  activityImage.src = randomActivity.image;
  activityTitle.textContent = randomActivity.title;
  activityBenefit.textContent = "Manfaat: " + randomActivity.benefit;
  activityTips.textContent = "Tips: " + randomActivity.tips;
  
  activityBox.style.display = "block";
}
