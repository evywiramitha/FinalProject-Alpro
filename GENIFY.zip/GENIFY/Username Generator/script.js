let existingUsernames = []; // Array untuk menyimpan username yang sudah dibuat

function generateUsername() {
  const category = document.getElementById("category").value;
  const length = parseInt(document.getElementById("length").value);
  const includeNumbers = document.getElementById("includeNumbers").checked;
  const includeSymbols = document.getElementById("includeSymbols").checked;
  const includeUppercase = document.getElementById("includeUppercase").checked;

  let characters = "abcdefghijklmnopqrstuvwxyz";
  if (includeUppercase) characters += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  if (includeNumbers) characters += "0123456789";
  if (includeSymbols) characters += "_.";

  let username = "";
  do {
    username = category + "_"; // Prefix username dengan kategori
    for (let i = 0; i < length; i++) {
      username += characters.charAt(Math.floor(Math.random() * characters.length));
    }
  } while (existingUsernames.includes(username)); // Ulangi jika username sudah ada

  existingUsernames.push(username); // Simpan username ke array
  document.getElementById("result").innerText = "Generated Username: " + username;
}
